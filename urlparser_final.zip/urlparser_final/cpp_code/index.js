const f = require('fastify')()

f.post('/simple', async (request) => {
    const { url } = request.body
    return { parsed: url }
})

f.post('/href', async (request) => {
    const { url } = request.body
    return { parsed: new URL(url).href }
})

f.listen({ port: 3000 })
    .then(() => console.log('listening on port 3000'))
    .catch(err => console.error(err))