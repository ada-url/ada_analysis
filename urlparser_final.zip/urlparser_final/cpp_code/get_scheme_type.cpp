std::string_view is_special_list[] = {"http", " ",   
   "https", "ws", "ftp",  "wss", "file",  " "};

enum type {
  HTTP = 0, NOT_SPECIAL = 1, HTTPS = 2, WS = 3,
  FTP = 4, WSS = 5, FILE = 6 };

type get_scheme_type(std::string_view scheme)  {
  if (scheme.empty()) { return NOT_SPECIAL; }
  int hash_value = (2 * scheme.size() + (unsigned)(scheme[0])) & 7;
  std::string_view target = is_special_list[hash_value];
  if ((target[0] == scheme[0]) && (target.substr(1) == scheme.substr(1))) {
    return type(hash_value);
  } else { return NOT_SPECIAL; }
}