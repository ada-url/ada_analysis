void to_lower_ascii(char * input, size_t length) {
    auto broadcast = [](uint8_t v) -> uint64_t { return 0x101010101010101 * v; };
    uint64_t broadcast_80 = broadcast(0x80);
    uint64_t broadcast_Ap = broadcast(128 - 'A');
    uint64_t broadcast_Zp = broadcast(128 - 'Z' - 1);
    size_t i = 0;

    for (; i + 7 < length; i += 8) {
      uint64_t word{};
      memcpy(&word, input + i, sizeof(word));
      word ^= (((word+broadcast_Ap)^(word+broadcast_Zp))&broadcast_80)>>2;
      memcpy(input + i, &word, sizeof(word));
    }
    if (i < length) {
      uint64_t word{};
      memcpy(&word, input + i, length - i);
      word ^= (((word+broadcast_Ap)^(word+broadcast_Zp))&broadcast_80)>>2;
      memcpy(input + i, &word, length - i);
    }
  }